**Modifiable code**

Code in this folder is allowed to be fully customized and modified according to your needs.
